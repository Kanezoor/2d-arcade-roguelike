# Room wall / trigger rotation fix

This patch fixes Matter body rotation order in the current Phaser 3.60 project.

## Files

- `src/managers/RoomManager.js`
  - Creates each Matter body before applying wall rotation in `createStaticWallSegment()`.
  - Applies the same order to circular boundary segments in `createCircularBoundry()`.
- `src/world/RoomEntranceRuntime.js`
  - Creates Matter bodies before rotating vestibule walls, gate panels, entry sensors, and exit triggers.
- `src/tests/room-ports.test.js`
  - Strengthens the fake Matter runtime and adds a regression test for an east-facing vestibule/exit trigger.

## Apply

1. Back up or commit your current project.
2. Extract this ZIP into the project root and allow these three files to replace the existing files.
3. Run all regression tests from the project root:

```bash
node src/tests/floor-generator.test.js
node src/tests/room-navigation.test.js
node src/tests/room-transition.test.js
node src/tests/run-state.test.js
node src/tests/room-ports.test.js
```

## Why this fixes the issue

A Phaser Game Object's regular `setRotation()` can rotate its display object before Matter is attached, but the newly created Matter body may still have angle 0. After `matter.add.gameObject(...)`, Phaser's Matter-aware `setRotation()` updates the physics body angle too.

The incorrect order made the two long vertical side-wall rectangles behave as horizontal bodies at the room's vertical midpoint. It also made east/west sensor bodies horizontal, which could overlap a player spawned at the side entrance and immediately trigger a return transition.
