
export default class InventoryUI {
  constructor(scene, inventory) {
    this.scene = scene;
    this.inventory = inventory;
    this.isOpen = false;
    this.objects = [];
    this.hoveredItemId = null;
    this.itemVisuals = new Map();

    this.gridX = 0;
    this.gridY = 0;
    this.cellSize = 42;

    this.dragState = null;
    this.dragPreviewGraphics = null;
  }

  addObject(object, depth = 2000) {
    object.setDepth(depth);
    object.setScrollFactor(0);
    this.objects.push(object);
    return object;
  }

  open() {
    if (
      this.isOpen ||
      this.scene.isLevelUpOpen
    ) {
      return;
    }

    this.isOpen = true;
    this.scene.isInventoryOpen = true;
    this.scene.matter.world.pause();

    this.createUI();

    this.scene.input.on(
      "pointermove",
      this.handlePointerMove,
      this
    );

    this.scene.input.on(
      "pointerup",
      this.handlePointerUp,
      this
    );

    this.scene.input.keyboard.on(
      "keydown-R",
      this.handleRotateKey,
      this
    );

    this.scene.input.keyboard.on(
      "keydown-Q",
      this.handleDropKey,
      this
    );
  }

  close() {
    if (!this.isOpen) {
      return;
    }

    this.scene.input.off(
      "pointermove",
      this.handlePointerMove,
      this
    );

    this.scene.input.off(
      "pointerup",
      this.handlePointerUp,
      this
    );

    this.scene.input.keyboard.off(
      "keydown-R",
      this.handleRotateKey,
      this
    );

    this.scene.input.keyboard.off(
      "keydown-Q",
      this.handleDropKey,
      this
    );

    this.cancelDrag();

    this.objects.forEach(object => {
      object.destroy();
    });

    this.objects = [];
    this.itemVisuals.clear();
    this.dragPreviewGraphics = null;
    this.hoveredItemId = null;
    this.isOpen = false;
    this.scene.isInventoryOpen = false;
    this.scene.matter.world.resume();
  }

  createUI() {
    const scene = this.scene;

    const centerX = scene.scale.width / 2;
    const centerY = scene.scale.height / 2;

    const panelWidth = 700;
    const panelHeight = 500;

    const panelLeft = centerX - panelWidth / 2;
    const panelTop = centerY - panelHeight / 2;

    this.addObject(
      scene.add.rectangle(
        centerX,
        centerY,
        panelWidth,
        panelHeight,
        0x111111,
        0.97
      ),
      2000
    );

    this.addObject(
      scene.add.rectangle(
        centerX,
        centerY,
        panelWidth,
        panelHeight,
        0x000000,
        0
      ).setStrokeStyle(2, 0x888888),
      2001
    );

    this.addObject(
      scene.add.text(
        centerX,
        panelTop + 35,
        "INVENTORY",
        {
          fontFamily: "sans-serif",
          fontSize: "28px",
          color: "#ffffff"
        }
      ).setOrigin(0.5),
      2002
    );

    this.addObject(
      scene.add.text(
        centerX,
        panelTop + 68,
        "8 × 4 STORAGE",
        {
          fontFamily: "sans-serif",
          fontSize: "14px",
          color: "#aaaaaa"
        }
      ).setOrigin(0.5),
      2002
    );

    this.createGrid(panelLeft + 28, panelTop + 130);
    this.createDetailsPanel(panelLeft + 385, panelTop + 140);

    this.addObject(
      scene.add.text(
        centerX,
        panelTop + panelHeight - 22,
        "TAB — Close inventory",
        {
          fontFamily: "sans-serif",
          fontSize: "14px",
          color: "#aaaaaa"
        }
      ).setOrigin(0.5),
      2002
    );
  }

  createGrid(gridX, gridY) {
    this.gridX = gridX;
    this.gridY = gridY;
    this.cellSize = 42;
    const cellSize = this.cellSize;
    this.itemVisuals.clear();

    for (let row = 0; row < this.inventory.height; row++) {
      for (let column = 0; column < this.inventory.width; column++) {
        const x = gridX + column * cellSize;
        const y = gridY + row * cellSize;

        this.addObject(
          this.scene.add.rectangle(
            x + cellSize / 2,
            y + cellSize / 2,
            cellSize - 3,
            cellSize - 3,
            0x292929,
            1
          ).setStrokeStyle(1, 0x666666),
          2002
        );
      }
    }

    this.renderItems(gridX, gridY, cellSize);
  }

  renderItems(gridX, gridY, cellSize) {
    for (const placement of this.inventory.getItems()) {
      const { item, x, y } = placement;

      const footprint = this.inventory.getRotatedFootprint(item);
      const color = this.getItemColor(item);

      const visuals = {
        cells: [],
        label: null
      };

      footprint.forEach(([offsetX, offsetY]) => {
        const cellX = x + offsetX;
        const cellY = y + offsetY;

        const cell = this.addObject(
          this.scene.add.rectangle(
            gridX + cellX * cellSize + cellSize / 2,
            gridY + cellY * cellSize + cellSize / 2,
            cellSize - 5,
            cellSize - 5,
            color,
            1
          ).setStrokeStyle(1, 0xffffff, 0.7),
          2003
        );

        cell.setInteractive({
          useHandCursor: true
        });

        cell.on("pointerover", () => {
          this.showItemDetails(item);
        });

        cell.on("pointerout", () => {
          this.clearItemDetails(item);
        });

        cell.on("pointerdown", pointer => {
          const currentCellX = Math.floor(
            (pointer.x - this.gridX) / this.cellSize
          );

          const currentCellY = Math.floor(
            (pointer.y - this.gridY) / this.cellSize
          );

          this.startDrag(
            item,
            currentCellX,
            currentCellY,
            pointer
          );
        });

        visuals.cells.push(cell);
      });

      // A short label identifies the item in the grid.
      const firstCell = footprint[0];
      const initials = item.definition.name
        .split(/\s+/)
        .map(word => word[0])
        .join("")
        .slice(0, 3)
        .toUpperCase();

      visuals.label = this.addObject(
        this.scene.add.text(
          gridX + (x + firstCell[0]) * cellSize + cellSize / 2,
          gridY + (y + firstCell[1]) * cellSize + cellSize / 2,
          initials,
          {
            fontFamily: "sans-serif",
            fontSize: "11px",
            color: "#ffffff",
            align: "center"
          }
        ).setOrigin(0.5),
        2004
      );

      this.itemVisuals.set(
        item.instanceId,
        visuals
      );
    }
  }

  
startDrag(item, cellX, cellY, pointer) {
  if (!this.isOpen || this.dragState) {
    return;
  }

  const placement = this.inventory.getPlacement(
    item.instanceId
  );

  const visuals = this.itemVisuals.get(
    item.instanceId
  );

  const footprint = this.inventory.getRotatedFootprint(item);

  const anchorIndex = footprint.findIndex(
    ([offsetX, offsetY]) =>
      offsetX === cellX - placement.x &&
      offsetY === cellY - placement.y
  );

  if (!placement || !visuals) {
    return;
  }

  this.dragState = {
    item,
    instanceId: item.instanceId,

    offsetX: cellX - placement.x,
    offsetY: cellY - placement.y,

    targetX: placement.x,
    targetY: placement.y,
    isValid: true,
    targetRotation: item.rotation,
    anchorIndex: anchorIndex >= 0 ? anchorIndex : 0,
    pointerX: pointer.x,
    pointerY: pointer.y,
  };

  visuals.cells.forEach(cell => {
    cell.setAlpha(0.4);
  });

  visuals.label.setAlpha(0.4);

  if (!this.dragPreviewGraphics) {
    this.dragPreviewGraphics = this.addObject(
      this.scene.add.graphics(),
      2005
    );
  }

  this.showItemDetails(item);
  this.updateDragPreview(pointer);
}

handlePointerMove(pointer) {
  if (!this.dragState) {
    return;
  }

  this.updateDragPreview(pointer);
}

handlePointerUp(pointer) {
  if (!this.dragState) {
    return;
  }

  this.updateDragPreview(pointer);

  const drag = this.dragState;

  if (drag.isValid) {
    const moved = this.inventory.moveItem(
      drag.instanceId,
      drag.targetX,
      drag.targetY,
      drag.targetRotation
    );

    if (moved) {
      this.updateItemVisuals(drag.item);
    }
  }

  this.cancelDrag();
}


handleDropKey(event) {
  if (
    !this.isOpen ||
    this.dragState ||
    !this.hoveredItemId
  ) {
    return;
  }

  const placement = this.inventory.getPlacement(
    this.hoveredItemId
  );

  if (!placement) {
    return;
  }

  event?.preventDefault();

  const item = placement.item;

  const worldItem = this.scene.createWorldItem(item);

  if (!worldItem) {
    return;
  }

  const removedItem = this.inventory.removeItem(
    item.instanceId
  );

  if (!removedItem) {
    worldItem.destroy();
    return;
  }

  this.clearItemDetails(removedItem);
  this.removeItemVisuals(removedItem.instanceId);
}

removeItemVisuals(instanceId) {
  const visuals = this.itemVisuals.get(instanceId);

  if (!visuals) {
    return;
  }

  const objects = [
    ...visuals.cells,
    visuals.label
  ];

  objects.forEach(object => {
    const index = this.objects.indexOf(object);

    if (index !== -1) {
      this.objects.splice(index, 1);
    }

    if (object?.active) {
      object.destroy();
    }
  });

  this.itemVisuals.delete(instanceId);
}


handleRotateKey(event) {
  if (!this.dragState || event?.repeat) {
    return;
  }

  event?.preventDefault();
  this.rotateDraggedItem();
}

rotateDraggedItem() {
  const drag = this.dragState;

  if (!drag) {
    return;
  }

  const nextRotation = this.inventory.normalizeRotation(
    drag.targetRotation + 1
  );

  const rotatedFootprint =
    this.inventory.getRotatedFootprint(
      drag.item,
      nextRotation
    );

  const anchor =
    rotatedFootprint[drag.anchorIndex] ??
    rotatedFootprint[0];

  drag.targetRotation = nextRotation;
  drag.offsetX = anchor[0];
  drag.offsetY = anchor[1];

  this.updateDragPreview({
    x: drag.pointerX,
    y: drag.pointerY
  });
}

updateDragPreview(pointer) {
  const drag = this.dragState;
  const graphics = this.dragPreviewGraphics;

  if (!drag || !graphics) {
    return;
  }

  drag.pointerX = pointer.x;
  drag.pointerY = pointer.y;

  graphics.clear();

  const gridRight =
    this.gridX +
    this.inventory.width * this.cellSize;

  const gridBottom =
    this.gridY +
    this.inventory.height * this.cellSize;

  const pointerIsInsideGrid =
    pointer.x >= this.gridX &&
    pointer.x < gridRight &&
    pointer.y >= this.gridY &&
    pointer.y < gridBottom;

  if (!pointerIsInsideGrid) {
    drag.isValid = false;
    return;
  }

  const pointerColumn = Math.floor(
    (pointer.x - this.gridX) / this.cellSize
  );

  const pointerRow = Math.floor(
    (pointer.y - this.gridY) / this.cellSize
  );

  drag.targetX = pointerColumn - drag.offsetX;
  drag.targetY = pointerRow - drag.offsetY;

  drag.isValid = this.inventory.canPlace(
    drag.item,
    drag.targetX,
    drag.targetY,
    drag.targetRotation,
    drag.instanceId
  );

  const color = drag.isValid
    ? 0x55dd88
    : 0xff5555;

  graphics.fillStyle(color, 0.45);
  graphics.lineStyle(2, color, 0.95);

  const footprint = this.inventory.getRotatedFootprint(
    drag.item,
    drag.targetRotation
  );

  footprint.forEach(([offsetX, offsetY]) => {
    const x =
      this.gridX +
      (drag.targetX + offsetX) * this.cellSize + 2;

    const y =
      this.gridY +
      (drag.targetY + offsetY) * this.cellSize + 2;

    graphics.fillRect(
      x,
      y,
      this.cellSize - 5,
      this.cellSize - 5
    );

    graphics.strokeRect(
      x,
      y,
      this.cellSize - 5,
      this.cellSize - 5
    );
  });
}

updateItemVisuals(item) {
  const placement = this.inventory.getPlacement(
    item.instanceId
  );

  const visuals = this.itemVisuals.get(
    item.instanceId
  );

  if (!placement || !visuals) {
    return;
  }

  const footprint = this.inventory.getRotatedFootprint(
    item
  );

  footprint.forEach(([offsetX, offsetY], index) => {
    const cell = visuals.cells[index];

    if (!cell) {
      return;
    }

    const cellX = placement.x + offsetX;
    const cellY = placement.y + offsetY;

    cell.setPosition(
      this.gridX +
        cellX * this.cellSize +
        this.cellSize / 2,
      this.gridY +
        cellY * this.cellSize +
        this.cellSize / 2
    );
  });

  const firstCell = footprint[0];

  visuals.label.setPosition(
    this.gridX +
      (placement.x + firstCell[0]) *
        this.cellSize +
      this.cellSize / 2,
    this.gridY +
      (placement.y + firstCell[1]) *
        this.cellSize +
      this.cellSize / 2
  );
}

cancelDrag() {
  if (this.dragState) {
    const visuals = this.itemVisuals.get(
      this.dragState.instanceId
    );

    if (visuals) {
      visuals.cells.forEach(cell => {
        cell.setAlpha(1);
      });

      visuals.label.setAlpha(1);
    }
  }

  this.dragState = null;

  if (this.dragPreviewGraphics) {
    this.dragPreviewGraphics.clear();
  }
}

  createDetailsPanel(x, y) {
    this.addObject(
      this.scene.add.rectangle(
        x + 135,
        y + 95,
        270,
        220,
        0x242424,
        1
      ).setStrokeStyle(1, 0x666666),
      2002
    );

    this.detailName = this.addObject(
      this.scene.add.text(
        x + 14,
        y + 20,
        "ITEM DETAILS",
        {
          fontFamily: "sans-serif",
          fontSize: "20px",
          color: "#ffffff",
          wordWrap: { width: 240 }
        }
      ),
      2003
    );

    this.detailCategory = this.addObject(
      this.scene.add.text(
        x + 14,
        y + 55,
        "",
        {
          fontFamily: "sans-serif",
          fontSize: "13px",
          color: "#aaaaaa"
        }
      ),
      2003
    );

    this.detailDescription = this.addObject(
      this.scene.add.text(
        x + 14,
        y + 85,
        "Hover over an item to inspect it.",
        {
          fontFamily: "sans-serif",
          fontSize: "16px",
          color: "#dddddd",
          wordWrap: { width: 240 },
          lineSpacing: 4
        }
      ),
      2003
    );

    this.detailFootprint = this.addObject(
      this.scene.add.text(
        x + 14,
        y + 185,
        "",
        {
          fontFamily: "sans-serif",
          fontSize: "13px",
          color: "#aaaaaa"
        }
      ),
      2003
    );
  }

  showItemDetails(item) {
    this.hoveredItemId = item.instanceId;

    this.detailName.setText(item.definition.name);
    this.detailCategory.setText(
      item.definition.category.toUpperCase()
    );
    this.detailDescription.setText(
      item.definition.description
    );

    const footprint = this.inventory.getRotatedFootprint(item);

    this.detailFootprint.setText(
      `Size: ${footprint.length} cells`
    );
  }

  clearItemDetails(item) {
    if (this.hoveredItemId !== item.instanceId) {
      return;
    }

    this.hoveredItemId = null;

    this.detailName.setText("ITEM DETAILS");
    this.detailCategory.setText("");
    this.detailDescription.setText(
      "Hover over an item to inspect it."
    );
    this.detailFootprint.setText("");
  }

  getItemColor(item) {
    switch (item.definition.category) {
      case "weaponModule":
        return 0x385e9d;

      case "consumable":
        return 0x39805c;

      case "questItem":
        return 0xa88132;

      default:
        return 0x666666;
    }
  }
}