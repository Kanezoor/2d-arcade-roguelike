
export default class WorldItemPickupSystem {
  constructor(scene) {
    this.scene = scene;
    this.pickupRadius = 65;
    this.nearestWorldItem = null;

    this.pickupKey = scene.input.keyboard.addKey(
      Phaser.Input.Keyboard.KeyCodes.E
    );

    this.feedbackMessage = "";
    this.feedbackUntil = 0;

    this.promptText = scene.add.text(
      scene.scale.width / 2,
      scene.scale.height - 45,
      "",
      {
        fontFamily: "sans-serif",
        fontSize: "18px",
        color: "#ffffff",
        backgroundColor: "#171717",
        padding: { x: 12, y: 8 },
        align: "center"
      }
    )
      .setOrigin(0.5)
      .setScrollFactor(0)
      .setDepth(1500)
      .setVisible(false);
  }

  update() {
    const scene = this.scene;

    if (
      scene.isGameOver ||
      scene.isInventoryOpen ||
      scene.isLevelUpOpen ||
      !scene.player?.sprite
    ) {
      this.nearestWorldItem = null;
      this.promptText.setVisible(false);
      return;
    }

    this.nearestWorldItem = this.findNearestWorldItem();

    if (
      Phaser.Input.Keyboard.JustDown(this.pickupKey) &&
      this.nearestWorldItem
    ) {
      const worldItem = this.nearestWorldItem;
      const itemName = worldItem.item.definition.name;

      if (this.tryPickup(worldItem)) {
        this.showFeedback(`Picked up: ${itemName}`, 1000);
        this.nearestWorldItem = null;
      } else {
        this.showFeedback("Inventory full — make space", 1400);
      }
    }

    if (scene.time.now < this.feedbackUntil) {
      this.promptText
        .setText(this.feedbackMessage)
        .setVisible(true);

      return;
    }

    if (this.nearestWorldItem) {
      const item = this.nearestWorldItem.item;
      const position = this.findInventoryPosition(item);

      if (position) {
        this.promptText.setText(
          `[E] Pick up: ${item.definition.name}`
        );
      } else {
        this.promptText.setText(
          `Inventory full: ${item.definition.name}`
        );
      }

      this.promptText.setVisible(true);
    } else {
      this.promptText.setVisible(false);
    }
  }

  findNearestWorldItem() {
    const scene = this.scene;
    const playerSprite = scene.player.sprite;

    let nearest = null;
    let nearestDistance = this.pickupRadius;

    for (const container of scene.worldItems.getChildren()) {
      const worldItem = container.worldItem;

      if (!worldItem || !worldItem.active) {
        continue;
      }

      const distance = Phaser.Math.Distance.Between(
        playerSprite.x,
        playerSprite.y,
        container.x,
        container.y
      );

      if (distance <= nearestDistance) {
        nearest = worldItem;
        nearestDistance = distance;
      }
    }

    return nearest;
  }

  findInventoryPosition(item) {
    const inventory = this.scene.player.inventory;
    const startingRotation = item.rotation ?? 0;

    for (let offset = 0; offset < 4; offset++) {
      const rotation = inventory.normalizeRotation(
        startingRotation + offset
      );

      const position = inventory.findFirstFit(
        item,
        rotation
      );

      if (position) {
        return position;
      }
    }

    return null;
  }

  tryPickup(worldItem) {
    if (!worldItem?.active) {
      return false;
    }

    const inventory = this.scene.player.inventory;
    const item = worldItem.item;
    const position = this.findInventoryPosition(item);

    if (!position) {
      return false;
    }

    const added = inventory.addItem(
      item,
      position.x,
      position.y,
      position.rotation
    );

    if (!added) {
      return false;
    }

    worldItem.destroy();

    return true;
  }

  showFeedback(message, duration) {
    this.feedbackMessage = message;
    this.feedbackUntil = this.scene.time.now + duration;
  }
}
