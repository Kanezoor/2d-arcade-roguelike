
export default class Projectile {
  constructor(
    scene,
    x,
    y,
    texture,
    damage,
    speed,
    angle,
    range,
    projectileLifetime,
    owner,
    team = 'player',
    hitReactionDistance = 0,
    hitPushDuration = 0,
    hitStunDuration = 0,
    penetrationSpeedRetention = 0.85,
  ) {
    this.scene = scene;
    this.owner = owner;

    this.sprite = scene.matter.add.sprite(
      x,
      y,
      texture,
      undefined,
      {
        isSensor: true,
        ignoreGravity: true,
        frictionAir: 0,
      }
    );

    this.sprite.setFixedRotation();
    scene.projectiles.add(this.sprite);

    this.baseDamage = damage;
    this.speed = speed;
    this.currentSpeed = speed;
    this.travelAngle = angle;

    this.startX = x;
    this.startY = y;
    this.age = 0;
    this.distanceTravelled = 0;
    this.previousX = x;
    this.previousY = y;
    this.maxRange = range;
    this.maxLifetime = projectileLifetime;

    this.isMagnetic = owner.hasPassive?.('magneticCore') === true;
    this.isPiercing = owner.hasPassive?.('piercingCore') === true;
    this.hitTargets = new Set();
    this.remainingHits = this.isPiercing ? 2 : 1;

    this.team = team;
    this.hitReactionDistance = hitReactionDistance;
    this.hitPushDuration = hitPushDuration;
    this.hitStunDuration = hitStunDuration;

    this.penetrationSpeedRetention = Phaser.Math.Clamp(
      penetrationSpeedRetention,
      0,
      1,
    );

    this.sprite.damage = this.baseDamage;
    this.sprite.isMagnetic = this.isMagnetic;
    this.sprite.isPiercing = this.isPiercing;
    this.sprite.owner = owner;
    this.sprite.team = team;
    this.sprite.hitReactionDistance = this.hitReactionDistance;
    this.sprite.hitPushDuration = this.hitPushDuration;
    this.sprite.hitStunDuration = this.hitStunDuration;

    this.sprite.setVelocity(
      Math.cos(this.travelAngle) * this.currentSpeed,
      Math.sin(this.travelAngle) * this.currentSpeed,
    );

    this.sprite.projectile = this;
  }

  canHitTarget(target) {
    return !this.hitTargets.has(target);
  }

  registerHit(target) {
    if (!this.canHitTarget(target)) {
      return false;
    }

    this.hitTargets.add(target);
    this.remainingHits--;

    return true;
  }

  applyPenetrationSpeedLoss() {
    if (!this.isPiercing) {
      return;
    }

    if (this.remainingHits <= 0) {
      return;
    }

    this.currentSpeed *= this.penetrationSpeedRetention;

    this.sprite.setVelocity(
      Math.cos(this.travelAngle) * this.currentSpeed,
      Math.sin(this.travelAngle) * this.currentSpeed,
    );
  }

  getImpactDamage() {
    const referenceSpeed = 5;

    const speedRatio = this.currentSpeed / referenceSpeed;

    const speedMultiplier = Phaser.Math.Clamp(
      Math.sqrt(speedRatio),
      0.75,
      1.5,
    );

    return this.baseDamage * speedMultiplier;
  }

  updateLifecycle(delta) {
    this.age += delta;

    const dx = this.sprite.x - this.previousX;
    const dy = this.sprite.y - this.previousY;

    this.distanceTravelled += Math.hypot(dx, dy);

    this.previousX = this.sprite.x;
    this.previousY = this.sprite.y;

    if (
      this.maxLifetime > 0 &&
      this.age >= this.maxLifetime
    ) {
      this.sprite.destroy();
      return false;
    }

    if (
      this.maxRange > 0 &&
      this.distanceTravelled >= this.maxRange
    ) {
      this.sprite.destroy();
      return false;
    }

    return true;
  }


  update(delta) {
    if (!this.sprite.active) {
      return;
    }

    if (!this.updateLifecycle(delta)) {
      return;
    }

    if (!this.isMagnetic) {
      return;
    } 

    let closestTarget = null;
    let closestDistance = 100;

    const targets = [
      ...this.scene.enemies.getChildren(),
      ...this.scene.bosses.getChildren()
    ];

    const currentAngle = this.travelAngle;

    for (const target of targets) {
      if (!target.active) {
        continue;
      }

      const distance = Phaser.Math.Distance.Between(
        this.sprite.x,
        this.sprite.y,
        target.x,
        target.y
      );

      if (distance >= closestDistance) {
        continue;
      }

      const targetAngle = Phaser.Math.Angle.Between(
        this.sprite.x,
        this.sprite.y,
        target.x,
        target.y
      );

      const angleDifference = Math.abs(
        Phaser.Math.Angle.Wrap(targetAngle - currentAngle)
      );

      if (angleDifference > Phaser.Math.DegToRad(80)) {
        continue;
      }

      closestDistance = distance;
      closestTarget = target;
    }

    if (!closestTarget) return;

    const targetAngle = Phaser.Math.Angle.Between(
      this.sprite.x,
      this.sprite.y,
      closestTarget.x,
      closestTarget.y
    );

    const newAngle = Phaser.Math.Angle.RotateTo(
      currentAngle,
      targetAngle,
      0.015
    );

    this.travelAngle = newAngle;
 
    this.sprite.setVelocity(
      Math.cos(this.travelAngle) * this.currentSpeed,
      Math.sin(this.travelAngle) * this.currentSpeed,
    );
  }
}