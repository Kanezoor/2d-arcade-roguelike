export default class Boss {

  constructor(sprite, scene) {

    this.scene = scene;
    this.sprite = sprite;

    sprite.boss = this;

    this.maxHealth = 100;
    this.health = this.maxHealth;

    this.phase = 1;

    this.isDead = false;

    this.sprite.setImmovable(true);

    this.attackTimer = 0;
  }

  update(delta) {
    this.attackTimer += delta;

    if (this.attackTimer >= 2500) {
      this.attackTimer = 0;
      this.fireCone();
    }
  }

  takeDamage(amount) {

    if (this.isDead) return;

    this.health -= amount;

    if (this.health <= 0) {
      this.health = 0;
      this.die();
      return;
    }

    if (this.health <= this.maxHealth / 2) {
      this.phase = 2;
    }
  }

  fireCone() {
    const player = this.scene.player.sprite;
    const baseAngle = Phaser.Math.Angle.Between(this.sprite.x, this.sprite.y, player.x, player.y);

    const spread = Phaser.Math.DegToRad(30);

    const angles = [
      baseAngle - spread,
      baseAngle - spread / 2,
      baseAngle,
      baseAngle + spread / 2,
      baseAngle + spread
    ];

    angles.forEach(angle => {
      const bullet = this.scene.projectiles.create(this.sprite.x, this.sprite.y, "bullet");
      
      const speed = 250;

      bullet.body.setVelocity(Math.cos(angle) * speed, Math.sin(angle) * speed);
      
      bullet.damage = 1;
      this.isBossProjectile = true;
    });


  }

  die() {

    this.isDead = true;

    this.sprite.destroy();

    console.log("Boss defeated!");

  }

}