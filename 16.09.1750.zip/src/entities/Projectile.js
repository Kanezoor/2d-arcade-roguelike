
export default class Projectile {
  constructor(
    scene,
    x,
    y,
    texture,
    damage,
    speed,
    angle,
    owner,
    team = 'player',
    hitReactionDistance = 0,
    hitPushDuration = 0,
    hitStunDuration = 0,
  ) {
    this.scene = scene;
    this.owner = owner;

    this.sprite = scene.matter.add.sprite(
      x,
      y,
      texture,
      undefined,
      {
        isSensor: true,
        ignoreGravity: true,
        frictionAir: 0,
      }
    );

    this.sprite.setFixedRotation();
    scene.projectiles.add(this.sprite);

    this.damage = damage;
    this.speed = speed;
    this.isMagnetic = owner.hasPassive?.('magneticCore') === true;
    this.isPiercing = owner.hasPassive?.('piercingCore') === true;
    this.hitTargets = new Set();
    this.remainingHits = this.isPiercing ? 2 : 1;

    this.team = team;
    this.hitReactionDistance = hitReactionDistance;
    this.hitPushDuration = hitPushDuration;
    this.hitStunDuration = hitStunDuration;

    this.sprite.damage = this.damage;
    this.sprite.isMagnetic = this.isMagnetic;
    this.sprite.isPiercing = this.isPiercing;
    this.sprite.owner = owner;
    this.sprite.team = team;
    this.sprite.hitReactionDistance = this.hitReactionDistance;
    this.sprite.hitPushDuration = this.hitPushDuration;
    this.sprite.hitStunDuration = this.hitStunDuration;

    this.sprite.setVelocity(
      Math.cos(angle) * this.speed,
      Math.sin(angle) * this.speed
    );

    this.sprite.projectile = this;
  }

  canHitTarget(target) {
    return !this.hitTargets.has(target);
  }

  registerHit(target) {
    if (!this.canHitTarget(target)) {
      return false;
    }

    this.hitTargets.add(target);
    this.remainingHits--;

    return true;
  }

  update() {
    if (!this.isMagnetic || !this.sprite.active) {
      return;
    }

    let closestTarget = null;
    let closestDistance = 100;

    const targets = [
      ...this.scene.enemies.getChildren(),
      ...this.scene.bosses.getChildren()
    ];

    const velocity = this.sprite.body.velocity;

    const currentAngle = Math.atan2(
      velocity.y,
      velocity.x,
    );

    const speed = Math.hypot(
      velocity.x,
      velocity.y,
    );

    for (const target of targets) {
      if (!target.active) {
        continue;
      }

      const distance = Phaser.Math.Distance.Between(
        this.sprite.x,
        this.sprite.y,
        target.x,
        target.y
      );

      if (distance >= closestDistance) {
        continue;
      }

      const targetAngle = Phaser.Math.Angle.Between(
        this.sprite.x,
        this.sprite.y,
        target.x,
        target.y
      );

      const angleDifference = Math.abs(
        Phaser.Math.Angle.Wrap(targetAngle - currentAngle)
      );

      if (angleDifference > Phaser.Math.DegToRad(80)) {
        continue;
      }

      closestDistance = distance;
      closestTarget = target;
    }

    if (!closestTarget) return;

    const targetAngle = Phaser.Math.Angle.Between(
      this.sprite.x,
      this.sprite.y,
      closestTarget.x,
      closestTarget.y
    );

    const newAngle = Phaser.Math.Angle.RotateTo(
      currentAngle,
      targetAngle,
      0.015
    );
 
    this.sprite.setVelocity(
      Math.cos(newAngle) * speed,
      Math.sin(newAngle) * speed,
    );
  }
}