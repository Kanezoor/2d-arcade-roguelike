import { createTextures } from "./textures.js";
import { createPlayer, updatePlayer } from "./player.js";
import { spawnEnemy, hitEnemy } from "./enemy.js";
import { drawUI, showGameOverScreen } from "./ui.js";

export class GameScene extends Phaser.Scene {
  constructor() {
    super('GameScene');
  }

  preload() {

  }

  create() {
    createTextures(this);

    createPlayer(this);

    this.projectiles = this.physics.add.group();

    this.enemies = this.physics.add.group();

    this.particles = this.add.group();

    this.score = 0;

    this.isGameOver = false;

  }

  update() {
    updatePlayer(this);

    drawUI(this);
  }
}